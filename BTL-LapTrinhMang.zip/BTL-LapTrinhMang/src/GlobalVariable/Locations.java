package GlobalVariable;

public interface Locations {
    String KITCHEN = "KITCHEN";
    String LIVING_ROOM = "LIVING_ROOM";
    String BATHROOM = "BATHROOM";
    String BEDROOM = "BEDROOM";
}

package GlobalVariable;

public interface Topics {
    String ROOM_TEMP = "ROOM_TEMP";
    String TV_SWITCH = "TV_SWITCH";
    String LIGHT_SWITCH = "LIGHT_SWITCH";
    String VOLUME_RANGE = "VOLUME_RANGE";
    String AC_TEMP = "AC_TEMP";   //  air conditioner
}

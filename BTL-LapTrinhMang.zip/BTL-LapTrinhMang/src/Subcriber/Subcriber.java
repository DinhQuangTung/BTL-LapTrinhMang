package Subcriber;

import GlobalVariable.*;

public class Subcriber implements Locations, Topics {
    public static void main(String[] args) throws Exception {

    }
}
